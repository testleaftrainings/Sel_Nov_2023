package com.salesforce.testcases;

import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.data.dynamic.FakerDataFactory;
import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC001_VerifyLogin extends ProjectSpecificMethods{
	@BeforeTest
	public void setValues() {
		testcaseName = "VerifyLogin";
		testDescription ="Verify Login functionality with positive data";
		authors="Hari";
		category ="Smoke";
		excelFileName="Login";
		
	}
	
	@Test
	public void runLogin() {
		
		/*
		 * System.out.println(FakerDataFactory.getCompanyName());
		 * System.out.println(FakerDataFactory.getFirstName());
		 * System.out.println(FakerDataFactory.getLastName());
		 */
		System.out.println(ConfigurationManager.configuration().getAge());
		System.out.println(ConfigurationManager.configuration().getAlive());
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLogin();
		/*clickCrmsfa()
		 * clickLead()
		 * clickCreateLead()
		 * enterCompanyName(FakerDataFactory.getCompanyName())
		 * enterFirstName(FakerDataFactory.getFirstName())
		 * enterLastName(FakerDataFactory.getLastName())
		 * clickSubmit()
		 * 
		 * 
		 */

	}

}
