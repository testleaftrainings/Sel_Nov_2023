package com.salesforce.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.framework.config.ConfigurationManager;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage enterUsername() {
		
		typeAndTab(locateElement(Locators.ID,"username"),ConfigurationManager.configuration().getUsername());
		reportStep("Username enterd successfully", "pass");
		return this;
	}
	public LoginPage enterPassword() {
		clearAndType(locateElement(Locators.ID,"password"),ConfigurationManager.configuration().getPassword());
		reportStep("Password enterd successfully", "pass");
		return this;
	}
	
	public LoginPage clickLogin() {		
		click(locateElement(Locators.ID,"Login"));
		reportStep("Login button is clicked successfully", "pass");
		return this;
	}
	
	
	
	
	
	

}
