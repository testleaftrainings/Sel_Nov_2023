package base;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnConstructor {

	String driver;
	int timeout;
	
	
	public LearnConstructor(){ //default constructor
		System.out.println(driver +" "+ timeout);
	}
	
	public LearnConstructor(String driver,int timeout){
		//parametrized constructor
		this.driver=driver;
		this.timeout=timeout;		
		System.out.println(this.driver+" "+this.timeout);
	}
		
	
	public void driverObj() {		
		System.out.println("From the normal method" +driver);
	}
	
	public static void main(String[] args) {	
		LearnConstructor lc=new LearnConstructor();//default constructor		
		LearnConstructor lc1=new LearnConstructor("chromedriver" ,10);
		
	}
	
	
	
	
	
	
	//static constructor  normalmethods
	
	/*
	 * System.out.println(lc.driver); System.out.println(lc.timeout);
	 */

}
