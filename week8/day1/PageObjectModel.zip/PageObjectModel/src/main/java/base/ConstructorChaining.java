package base;

public class ConstructorChaining {

	public ConstructorChaining() {
		System.out.println("From default Constructor");
	}
	
	
	public ConstructorChaining(String name) {
		this();
		System.out.println("From parametrized Constructor" +name);
	}
	
	
	public static void main(String[] args) {
	    new ConstructorChaining("Testleaf") ;
		
	}

}


//calling one constructor from other constructor is called Constructor chaining