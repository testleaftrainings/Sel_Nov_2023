package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LeadsPage  extends ProjectSpecificMethod {


	public LeadsPage (ChromeDriver driver) {
		this.driver=driver;
	}
	
	
	public CreatLeadPage clickCreatelead() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreatLeadPage(driver);
	}
	
	
	
}
