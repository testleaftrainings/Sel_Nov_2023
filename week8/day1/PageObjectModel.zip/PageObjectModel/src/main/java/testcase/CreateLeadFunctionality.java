package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class CreateLeadFunctionality extends ProjectSpecificMethod{

		
	@Test
	public void runLogin() {
		
		LoginPage lp=new LoginPage(driver);
		
		lp.enterUsername().enterPassword().clickLogin().clickCRMSFA().clickLeads()
		.clickCreatelead().enterCompanyName().enterFirstName().enterLastName().clickCreate()
		.verifyPagetitle();
		
		
		
		
	}
	
	
	
}
