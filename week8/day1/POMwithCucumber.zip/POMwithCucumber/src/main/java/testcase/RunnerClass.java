package testcase;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/TC001_login.feature" ,glue="pages",monochrome=true)
public class RunnerClass extends ProjectSpecificMethod{

}
