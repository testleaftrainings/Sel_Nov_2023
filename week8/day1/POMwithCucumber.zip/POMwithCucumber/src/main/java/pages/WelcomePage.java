package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod{

	public WelcomePage (ChromeDriver driver) {
		this.driver=driver;
	}
	
	@Then("Welcome page is displayed")
	public WelcomePage verifyTitle() {	
		System.out.println(driver.getTitle());
		return this;
	}
	
		
	public MyhomePage clickCRMSFA() {	
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyhomePage(driver);
	}
	
	public LoginPage clickLogout() {
	  System.out.println("Loggedout");
	  return new LoginPage(driver);

	}
	
	
}
