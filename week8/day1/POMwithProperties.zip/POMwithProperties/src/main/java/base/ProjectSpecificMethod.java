package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import utils.ReadExcel;

public class ProjectSpecificMethod {

	public ChromeDriver driver;
	public String filename;
	public static Properties prop;
	// driver=1234

	@Parameters({ "url" ,"propFile"})
	@BeforeMethod
	public void preCondition(String url,String language) throws IOException {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		FileInputStream fis = new FileInputStream("src/main/resources/"+language+".properties");
		prop = new Properties();
		prop.load(fis);
	}

	@AfterMethod
	public void postCondition() {
		driver.close();

	}

	@DataProvider(indices = 1)
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(filename);
		return data;
	}

}
