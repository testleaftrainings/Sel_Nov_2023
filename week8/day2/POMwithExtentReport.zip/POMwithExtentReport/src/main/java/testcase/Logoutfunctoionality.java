package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class Logoutfunctoionality extends ProjectSpecificMethod {


	@BeforeTest
	public void setValues() {
	
		testName="Login functionality";
		testDesc="Login with positive credentials";
		author="Prabha";
		category="Functional";
	}	
	
	
	@Test
	public void runLogin() throws IOException {

		LoginPage lp = new LoginPage();
		lp.enterUsername().enterPassword().clickLogin().clickLogout();

	}

}
