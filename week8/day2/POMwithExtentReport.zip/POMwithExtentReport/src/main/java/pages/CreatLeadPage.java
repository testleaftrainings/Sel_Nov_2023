package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreatLeadPage extends ProjectSpecificMethod {

	/*
	 * public CreatLeadPage(ChromeDriver driver) { this.driver = driver; }
	 */

	public CreatLeadPage enterCompanyName(String cname) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		return this;
	}

	public CreatLeadPage enterFirstName(String fname) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;
	}

	public CreatLeadPage enterLastName(String lname) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;
	}

	public CreatLeadPage enterPhno(String phno) {
		getDriver().findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phno);
		return this;
	}

	public ViewLeadPage clickCreate() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadPage();
	}

}
