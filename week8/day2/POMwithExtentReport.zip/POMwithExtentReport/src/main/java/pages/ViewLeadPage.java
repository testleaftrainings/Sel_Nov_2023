package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod {

	/*
	 * public ViewLeadPage(ChromeDriver driver) { this.driver = driver; }
	 */
	public ViewLeadPage verifyPagetitle() {
		System.out.println(getDriver().getTitle());
		return  this;
	}
}
