package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod {

	/*
	 * public LeadsPage(ChromeDriver driver) { this.driver = driver; }
	 */
	public CreatLeadPage clickCreatelead() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new CreatLeadPage();
	}

}
