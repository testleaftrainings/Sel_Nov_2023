package base;

public class LearnExceptionHandling {

	public static void main(String[] args) {		
		
		int x=10;
		int y=2;		
		String s=null;
		try {
			System.out.println(x/y);
			System.out.println(s.length());
		} catch (ArithmeticException e) {			
			System.out.println("Check your inputs " +e);
		}catch(Exception e){
			System.out.println(e);
		}
		/*
		 * finally { System.out.println("End of program"); }
		 */
	
	
	try {
		System.out.println(x/0);
	}finally {
		System.out.println("End of program");
	}
	
	
	
	
	
	
	}

}
