package base;

public class LearnEncapsulation {

	private int pwd=12345;
	
	//getter and setter methods
	//getter -->give access to read the value
	//setter -->give access to set the value
	
	
	public int getPwd() {
		return pwd;
	}

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}

	public static void main(String[] args) {
		LearnEncapsulation le=new LearnEncapsulation();
		System.out.println(le.pwd);

	}

}
