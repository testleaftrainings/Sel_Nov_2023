package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> tldriver = new ThreadLocal<RemoteWebDriver>();

	public void setDriver() {
		tldriver.set(new ChromeDriver());
	}

	public RemoteWebDriver getDriver() {
		RemoteWebDriver rDriver = tldriver.get();
		return rDriver;
	}

	public static Properties prop;
	public String filename;
	public String testName, testDesc, author, category;
	public static ExtentReports extent;
	public static ExtentTest test;

	@Parameters({ "url","propFile"})
	@BeforeMethod
	public void preCondition(String url,String language) throws IOException {
		setDriver();	
		getDriver().manage().window().maximize();
		getDriver().get(url);
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		FileInputStream fis = new FileInputStream("src/main/resources/"+language+".properties");
		prop = new Properties();
		prop.load(fis);
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}

	@DataProvider(indices = 1)
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(filename);
		return data;
	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html"); // empty file
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}

	public void reportStep(String status, String message) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		} else if (status.equalsIgnoreCase("fail")) {
			test.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
			throw new RuntimeException("Check the locator");
		}
	}

	public int takeSnap() throws IOException {
		int random = (int) (Math.random() * 9999);
		File screenshotAs = getDriver().getScreenshotAs(OutputType.FILE);
		File dest = new File("./snap/shot" + random + ".jpg");
		FileUtils.copyFile(screenshotAs, dest);
		return random;
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}
