package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyhomePage  extends ProjectSpecificMethod {

	

	/*
	 * public MyhomePage (ChromeDriver driver) { this.driver=driver; }
	 */
	
	
	public LeadsPage clickLeads() {
		
		getDriver().findElement(By.linkText(prop.getProperty("MyhomePage.Leads.linktext"))).click();
		return new LeadsPage();
		
	}
	
	/*
	 * public LeadsPage clickLeadsForFrench() {
	 * 
	 * driver.findElement(By.linkText("Prospects")).click(); return new
	 * LeadsPage(driver);
	 * 
	 * }
	 */
	
}
