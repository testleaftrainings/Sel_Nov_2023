package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class Loginfuntionality extends ProjectSpecificMethod{

		
	@Test
	public void runLogin() {
		
		LoginPage lp=new LoginPage();	//1234	
		lp.enterUsername().enterPassword().clickLogin();
		
		
	}
	
	//seq -->single thread
	//psm-->@test-->lp
	//shared the driver object-->static-->single reference to use the driver object
}
// ||el execution -->Multiple threads
//