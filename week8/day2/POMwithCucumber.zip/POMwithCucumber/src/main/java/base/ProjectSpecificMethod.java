package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	//public ChromeDriver driver;
	
	private static final ThreadLocal<RemoteWebDriver> tldriver=new ThreadLocal<RemoteWebDriver>();
	
	
	public void setDriver() {
		tldriver.set(new ChromeDriver());
	}	
	
	public RemoteWebDriver getDriver() {
		RemoteWebDriver rDriver = tldriver.get();
		return rDriver;
	}
	
	public String filename;
	public static Properties prop;
	
	

	@Parameters({ "url" ,"propFile"})
	@BeforeMethod
	public void preCondition(String url,String language) throws IOException {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get(url);
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		FileInputStream fis = new FileInputStream("src/main/resources/"+language+".properties");
		prop = new Properties();
		prop.load(fis);
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}

	@DataProvider(indices = 1)
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(filename);
		return data;
	}

}
