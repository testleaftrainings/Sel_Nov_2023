package stepdef;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login extends BaseClass {

	// feature package-->Tc001_login.feature-->Writing userstory using Given, when &
	// then
	// stepdef package-->Login java -->selenium script
	// --> Create normal methods for each feature file scenario step
	// to connect the feature file steps with the method of java class-->cucumber
	// annotations

	/*
	 * public ChromeDriver driver;
	 * 
	 * @Given("Launch the browser") public void launchBrowser() { driver = new
	 * ChromeDriver(); }
	 * 
	 * @And("Load the url") public void loadUrl() {
	 * driver.manage().window().maximize();
	 * driver.get("http://leaftaps.com/opentaps/");
	 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); }
	 */
	@Given("Enter the username as {string}")
	public void enterUsername(String uname) {
		driver.findElement(By.id("username")).sendKeys(uname);
	}

	@Given("Enter the password as {string}")
	public void enterPassword(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
	}

	@When("Click on Login button")
	public void clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Welcome page is displayed")
	public void VerifyWelcomePage() {
		System.out.println(driver.getTitle());
	}

	@But("Error message is displayed")
	public void error_message_is_displayed() {
		String errorMsg = driver
				.findElement(By.xpath("//p[text()='following error occurred during login: User not found.']"))
				.getText();
		System.out.println(errorMsg);
	}

	

}
